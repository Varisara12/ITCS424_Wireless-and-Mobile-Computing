import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ListViews',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: Scaffold(
        appBar: AppBar(title: Text('6188005: Bag shop')),
        body: BodyLayout(),
      ),
    );
  }
}

class BodyLayout extends StatelessWidget {
  @override
  int TotalAmount= 0;
  Widget build(BuildContext context) {
    return _myListView( context, TotalAmount);
  }
}

// replace this function with the code in the examples
Widget _myListView(BuildContext context, int TotalAmount) {
  return ListView(
    children: <Widget>[
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/adidas.jpg'),
        ),
        title: Text('Adidas Limited Bag'),
        subtitle: Text('Price: \$1400'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 1400;
          print('ADIDAS | TotalPriceAmount : $TotalAmount Baht');
        },
      ),
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/balen.jpg'),
        ),
        title: Text('Balenciaga Bag LV series'),
        subtitle: Text('Price: \$26000'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 26000;
          print('Balenciaga | TotalPriceAmount : $TotalAmount Baht');
        },
      ),
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/brown.jpg'),
        ),
        title: Text('Otop Bag for sale'),
        subtitle: Text('Price: \$150'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 150;
          print('Otop | TotalPriceAmount : $TotalAmount Baht');
        },
      ),
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/dior.jpg'),
        ),
        title: Text('Dior for pretty style series 2019'),
        subtitle: Text('Price: \$259000'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 259000;
          print('Dior | TotalPriceAmount : $TotalAmount Baht');
        },
      ),
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/converse.jpg'),
        ),
        title: Text('Converse Bag 2020'),
        subtitle: Text('Price: \$2450'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 2450;
          print('Converse | TotalPriceAmount : $TotalAmount Baht');
        },
      ),
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/channel.jpg'),
        ),
        title: Text('Channel Bag as Jannie Blackpink'),
        subtitle: Text('Price: \$380000'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 380000;
          print('Channel | TotalPriceAmount : $TotalAmount Baht');
        },
      ),
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/freitag.jpg'),
        ),
        title: Text('Freitag the most poppular bag for everyone '),
        subtitle: Text('Price: \$6500'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 6500;
          print('Freitag | TotalPriceAmount : $TotalAmount Baht');
        },
      ),
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/ikea.jpg'),
        ),
        title: Text('IKEA BAG for this year, blue color'),
        subtitle: Text('Price: \$100'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 100;
          print('IKEA | TotalPriceAmount : $TotalAmount Baht');
        },
      ),
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/nike.jpg'),
        ),
        title: Text('NIKE 2018'),
        subtitle: Text('Price: \$7690'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 7690;
          print('NIKE | TotalPriceAmount : $TotalAmount Baht');
        },
      ),
      ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/brown.jpg'),
        ),
        title: Text('Thailand bag which is so special, only available for this season'),
        subtitle: Text('Price: \$250'),
        trailing: Icon(Icons.keyboard_arrow_right),
        onTap: () {
          TotalAmount += 250;
          print('Thailand Special | TotalPriceAmount : $TotalAmount Baht');
        },
      ),

    ],
  );
}
